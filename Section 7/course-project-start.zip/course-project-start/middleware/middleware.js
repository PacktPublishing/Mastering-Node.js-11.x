const CommonMiddleware = require("./common");

module.exports = function Middleware(app) {
    CommonMiddleware(app);
}