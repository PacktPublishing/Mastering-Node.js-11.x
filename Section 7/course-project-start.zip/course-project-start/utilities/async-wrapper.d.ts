import {RequestHandler} from 'express';

export function AsyncWrapper(fn: RequestHandler);